﻿using System.Threading.Tasks;

namespace LoadDWVentas.Data.Interfaces
{
    public interface IDataServiceswhventas
    {
        Task LoadClientesAsync();
        Task LoadProductosAsync();
        Task LoadEmpleadosAsync();
        Task LoadShippersAsync();
        Task LoadVentasAsync();

        // Agregar las definiciones de los métodos adicionales
        Task LoadTiempoAsync();
        Task LoadClienteAtendidoAsync();

        // limpieza
        Task LimpiarTablasAsync();
    }
}
